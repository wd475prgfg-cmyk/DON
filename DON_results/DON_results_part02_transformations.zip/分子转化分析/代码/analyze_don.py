#!/usr/bin/env python3
"""DON per-sample candidate transformations and per-molecule degree; no RI cutoff assumed."""
import sys,io,csv,json,zipfile,hashlib,collections,math,importlib.util
from pathlib import Path
import numpy as np
import pandas as pd
import openpyxl
BASE=Path(__file__).resolve().parents[1]; DON=BASE.parent
spec=importlib.util.spec_from_file_location('upstream',DON/'Meta-Metabolome_Ecology-master/run_molecular_transformations.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
dbpath=BASE/'方法来源/Transformation_Database_07-2020.csv'
db=pd.read_csv(dbpath);trans=list(zip(db.Name,db.Mass))
for p in ['逐样本转化峰对','逐样本分子转化次数','处理记录']: (BASE/p).mkdir(exist_ok=True)
def write(path,header,rows):
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(rows)
summary=[];allnodes=[];allform=[];audit=[];validations=[];sampleindex=0
for archive in ['DON1.zip','DON2.zip']:
 with zipfile.ZipFile(DON/archive) as z:
  for filename in z.namelist():
   if not filename.endswith('.xlsx'):continue
   sampleindex+=1;group=filename.split('/')[0];sample=Path(filename).stem;sid=f'S{sampleindex:02d}';label=f'{sid}_{group}_{sample}'
   data=z.read(filename);w=openpyxl.load_workbook(io.BytesIO(data),read_only=True,data_only=True)
   it=iter(w.worksheets[0].values);header=next(it);records=[];stats=collections.Counter()
   for rowidx,row in enumerate(it,2):
    r=dict(zip(header,row));reason='included';mass=r.get('m/z');intensity=r.get('Intensity');iso=r.get('isotope kind')
    if not isinstance(mass,(int,float)) or not math.isfinite(mass):reason='missing_or_invalid_mz'
    elif iso not in (None,'','None'):reason='isotope_'+str(iso)
    elif not 200<=mass<=900:reason='outside_200_900_Da'
    elif not isinstance(intensity,(int,float)) or not math.isfinite(intensity) or intensity<=0:reason='nonpositive_or_invalid_intensity'
    elif any(not isinstance(r.get(e),(int,float)) or not math.isfinite(r[e]) or r[e]<0 or int(r[e])!=r[e] for e in ['C','H','O','N','P','S']):reason='invalid_element_composition'
    stats[reason]+=1
    if reason!='included':audit.append([sid,group,sample,archive,filename,rowidx,mass,iso,reason]);continue
    formula=''.join(e+(str(int(r[e])) if int(r[e])!=1 else '') for e in ['C','H','N','O','P','S'] if r[e])
    r.update(source_row=rowidx,formula=formula);records.append(r)
   w.close();records.sort(key=lambda r:(r['m/z'],r['source_row']))
   masses=np.array([r['m/z'] for r in records],dtype=float);matched=mod.match_all_masses(masses,trans)
   # Independent all-pair validation on a full small sample and subsets of larger ones.
   size=len(masses) if len(masses)<100 else 100
   ms=masses[:size];brute={}
   for x in range(len(ms)):
    for y in range(x):
     delta=ms[x]-ms[y];hits=np.flatnonzero((delta+mod.TOLERANCE>=db.Mass.values)&(delta-mod.TOLERANCE<=db.Mass.values))
     if len(hits):brute[(x,y)]=int(hits[-1])
   assert dict(mod.match_all_masses(ms,trans))==brute
   validations.append([sid,size,len(brute),'PASS'])
   degrees=np.zeros(len(records),dtype=int);types=[set() for _ in records];edges=[];profiles=collections.Counter()
   for (x,y),t in matched:
    rx,ry=records[x],records[y];delta=float(masses[x]-masses[y]);degrees[x]+=1;degrees[y]+=1;types[x].add(trans[t][0]);types[y].add(trans[t][0]);profiles[trans[t][0]]+=1
    edges.append([sid,group,sample,rx['source_row'],ry['source_row'],masses[x],masses[y],rx['formula'],ry['formula'],rx.get('class'),ry.get('class'),rx['Intensity'],ry['Intensity'],delta,trans[t][0],trans[t][1],delta-trans[t][1]])
   assert int(degrees.sum())==2*len(matched)
   write(BASE/'逐样本转化峰对'/f'{label}.csv',['sample_id','endmember','sample','source_row_x','source_row_y','mz_x','mz_y','formula_x','formula_y','class_x','class_y','intensity_x','intensity_y','mass_difference_Da','transformation','database_mass_Da','error_Da'],edges)
   nodes=[];fgroup=collections.defaultdict(list)
   for i,r in enumerate(records):
    node=[sid,group,sample,r['source_row'],r['m/z'],r['thero_mass'],r['formula'],*[r[e] for e in ['C','H','O','N','P','S']],r.get('class'),r['Intensity'],int(degrees[i]),len(types[i])];nodes.append(node);fgroup[r['formula']].append(i)
   nodeheader=['sample_id','endmember','sample','source_row','mz','theoretical_mass','formula','C','H','O','N','P','S','class','intensity','transformation_count','transformation_type_count']
   write(BASE/'逐样本分子转化次数'/f'{label}.csv',nodeheader,nodes);allnodes.extend(nodes)
   for formula,idx in fgroup.items():
    deg=int(degrees[idx].sum());allform.append([sid,group,sample,formula,len(idx),deg,len(set().union(*(types[i] for i in idx)))])
   summary.append([sid,group,sample,archive,filename,sum(stats.values()),len(records),sum(stats.values())-len(records),len(matched),int(np.count_nonzero(degrees)),int(np.count_nonzero(degrees==0)),float(degrees.mean()) if len(records) else 0,int(degrees.max()) if len(records) else 0])
   print(label,'input',sum(stats.values()),'eligible',len(records),'pairs',len(matched),flush=True)
write(BASE/'全部样本_分子转化次数.csv',nodeheader,allnodes)
write(BASE/'样本汇总.csv',['sample_id','endmember','sample','archive','source_file','input_rows','eligible_peaks','excluded_rows','matched_pairs','peaks_with_transformations','zero_transformation_peaks','mean_transformation_count','max_transformation_count'],summary)
write(BASE/'处理记录/排除行记录.csv',['sample_id','endmember','sample','archive','file','source_row','mz','isotope','reason'],audit)
write(BASE/'处理记录/独立算法核对.csv',['sample_id','tested_peaks','matched_pairs','result'],validations)
f=pd.DataFrame(allform,columns=['sample_id','endmember','sample','formula','peak_count','transformation_count','transformation_type_count']);f.to_csv(BASE/'逐样本_按分子式统计.csv',index=False,encoding='utf-8-sig')
g=f.groupby('formula').agg(samples_present=('sample_id','nunique'),peak_observations=('peak_count','sum'),total_transformation_count=('transformation_count','sum'),mean_per_present_sample=('transformation_count','mean'),max_in_one_sample=('transformation_count','max')).reset_index();g.to_csv(BASE/'全部样本_按分子式汇总.csv',index=False,encoding='utf-8-sig')
end=f.groupby(['endmember','formula']).agg(samples_present=('sample_id','nunique'),peak_observations=('peak_count','sum'),total_transformation_count=('transformation_count','sum'),mean_per_present_sample=('transformation_count','mean')).reset_index();end.to_csv(BASE/'各端元_按分子式汇总.csv',index=False,encoding='utf-8-sig')
# Excel summary; detailed per-peak counts and pairs stay in CSV to retain exact representations.
with pd.ExcelWriter(BASE/'分子转化次数统计.xlsx',engine='openpyxl') as x:
 pd.read_csv(BASE/'样本汇总.csv').to_excel(x,sheet_name='样本汇总',index=False)
 g.to_excel(x,sheet_name='全部样本按分子式汇总',index=False)
 for group,part in end.groupby('endmember'):part.to_excel(x,sheet_name=group,index=False)
provenance={'code_repository':'https://github.com/wd475prgfg-cmyk/Meta-Metabolome_Ecology-master','database_source':'https://raw.githubusercontent.com/danczakre/Meta-Metabolome_Ecology/master/Transformation_Database_07-2020.csv','database_sha256':hashlib.sha256(dbpath.read_bytes()).hexdigest(),'database_entries':len(trans),'tolerance_Da':mod.TOLERANCE,'mass_column':'m/z','mass_window':[200,900],'isotope_policy':'Exclude all explicitly annotated isotopes; keep blank/None','sample_count':len(summary),'eligible_peak_observations':len(allnodes),'matched_pairs':sum(s[8] for s in summary),'unique_formulas':len(g),'RI_rule':'Not supplied; no RI classification or normalization assumed','input_sha256':{a:hashlib.sha256((DON/a).read_bytes()).hexdigest() for a in ['DON1.zip','DON2.zip']}}
(BASE/'处理记录/分析参数.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2));print(json.dumps(provenance,ensure_ascii=False),flush=True)
