from pathlib import Path
import csv,collections,json,math
B=Path(__file__).resolve().parents[1]
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:yield from csv.DictReader(f)
summ=list(read(B/'样本汇总.csv'));assert len(summ)==60
report=[]
for p in sorted((B/'逐样本转化峰对').glob('*.csv')):
 nodes={int(r['source_row']):r for r in read(B/'逐样本分子转化次数'/p.name)};counts=collections.Counter();seen=set();n=0
 for r in read(p):
  x,y=int(r['source_row_x']),int(r['source_row_y']);assert (x,y) not in seen;seen.add((x,y));n+=1
  assert float(r['mz_x'])>float(r['mz_y'])
  delta=float(r['mz_x'])-float(r['mz_y']);db=float(r['database_mass_Da']);assert delta+1e-5>=db and delta-1e-5<=db
  for rowid,side in [(x,'x'),(y,'y')]:
   assert rowid in nodes
   assert float(r['mz_'+side])==float(nodes[rowid]['mz'])
   assert r['formula_'+side]==nodes[rowid]['formula'];counts[rowid]+=1
 for rowid,r in nodes.items():assert counts[rowid]==int(r['transformation_count'])
 s=next(s for s in summ if s['sample_id']==p.name[:3]);assert n==int(s['matched_pairs']);assert len(nodes)==int(s['eligible_peaks']);assert sum(counts.values())==2*n
 report.append({'sample_id':p.name[:3],'pairs_checked':n,'peaks_checked':len(nodes),'status':'PASS'})
assert len(report)==60
assert sum(int(r['total_transformation_count']) for r in read(B/'全部样本_按分子式汇总.csv'))==2*sum(r['pairs_checked'] for r in report)
(B/'处理记录/完整导出核对.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASS: 60 samples,',sum(r['pairs_checked'] for r in report),'pairs,',sum(r['peaks_checked'] for r in report),'peaks')
