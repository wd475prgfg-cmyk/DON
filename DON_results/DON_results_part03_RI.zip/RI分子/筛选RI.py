from pathlib import Path
import pandas as pd,json,zipfile
B=Path(__file__).resolve().parent;A=B.parent/'分子转化分析'
source=A/'全部样本_分子转化次数.csv'
if not source.exists():source=B/'全部分子_RI标记.csv'
df=pd.read_csv(source);df['RI_le1']=(df.transformation_count<=1).astype(int);df['RI_eq0']=(df.transformation_count==0).astype(int)
assert len(df)==188411 and (df.transformation_count>=0).all()
assert (df.RI_eq0<=df.RI_le1).all()
ri=df[df.RI_le1==1].copy();strict=df[df.RI_eq0==1].copy()
def save(x,name):x.to_csv(B/name,index=False,encoding='utf-8-sig')
save(df,'全部分子_RI标记.csv');save(ri,'RI分子_转化次数小于等于1.csv');save(strict,'严格RI分子_转化次数等于0.csv')
sample=df.groupby(['sample_id','endmember','sample'],sort=False).agg(eligible_peaks=('source_row','size'),RI_le1_peaks=('RI_le1','sum'),RI_eq0_peaks=('RI_eq0','sum')).reset_index();sample['count_eq1']=sample.RI_le1_peaks-sample.RI_eq0_peaks
sample['RI_le1_percent']=sample.RI_le1_peaks/sample.eligible_peaks*100;sample['RI_eq0_percent']=sample.RI_eq0_peaks/sample.eligible_peaks*100
save(sample,'逐样本RI汇总.csv')
end=sample.groupby('endmember',sort=False).agg(samples=('sample_id','nunique'),eligible_peaks=('eligible_peaks','sum'),RI_le1_peaks=('RI_le1_peaks','sum'),RI_eq0_peaks=('RI_eq0_peaks','sum')).reset_index();end['RI_le1_percent']=end.RI_le1_peaks/end.eligible_peaks*100;end['RI_eq0_percent']=end.RI_eq0_peaks/end.eligible_peaks*100
save(end,'10端元RI汇总.csv')
# Distinguish occurrence in any peak from all peaks of a formula passing within a sample.
sf=df.groupby(['endmember','sample_id','formula']).agg(peak_observations=('source_row','size'),min_degree=('transformation_count','min'),max_degree=('transformation_count','max'),RI_le1_peaks=('RI_le1','sum'),RI_eq0_peaks=('RI_eq0','sum')).reset_index()
for tag,threshold in [('le1',1),('eq0',0)]:
 sf['sample_any_RI_'+tag]=(sf.min_degree<=threshold).astype(int)
 sf['sample_all_RI_'+tag]=(sf.max_degree<=threshold).astype(int)
formula=sf.groupby(['endmember','formula']).agg(samples_detected=('sample_id','nunique'),peak_observations=('peak_observations','sum'),samples_any_RI_le1=('sample_any_RI_le1','sum'),samples_all_RI_le1=('sample_all_RI_le1','sum'),samples_any_RI_eq0=('sample_any_RI_eq0','sum'),samples_all_RI_eq0=('sample_all_RI_eq0','sum')).reset_index()
formula['always_RI_le1']=(formula.samples_all_RI_le1==formula.samples_detected).astype(int);formula['always_RI_eq0']=(formula.samples_all_RI_eq0==formula.samples_detected).astype(int)
save(formula,'各端元分子式RI检出汇总.csv');save(sf,'逐样本分子式RI明细.csv')
assert len(sample)==60 and len(end)==10
assert sample.RI_le1_peaks.sum()==len(ri) and sample.RI_eq0_peaks.sum()==len(strict)
for group,part in ri.groupby('endmember',sort=False):save(part,group+'_RI分子.csv')
with pd.ExcelWriter(B/'DON_RI分子及汇总.xlsx',engine='openpyxl') as x:
 end.to_excel(x,sheet_name='10端元汇总',index=False);sample.to_excel(x,sheet_name='60样本汇总',index=False);formula.to_excel(x,sheet_name='分子式检出汇总',index=False)
 for group,part in ri.groupby('endmember',sort=False):part.to_excel(x,sheet_name=group,index=False)
report={'sample_count':len(sample),'endmember_count':len(end),'eligible_peak_observations':len(df),'RI_le1_peak_observations':len(ri),'RI_eq0_peak_observations':len(strict),'degree_eq1_peak_observations':len(ri)-len(strict),'RI_le1_unique_formulas':ri.formula.nunique(),'RI_eq0_unique_formulas':strict.formula.nunique(),'definition_source':'https://github.com/wd475prgfg-cmyk/Meta-Metabolome_Ecology-master/blob/miyun-gw-lake-transformations/RI/README.md','database_identical_to_user_provided':True,'checks':'PASS: 60 samples, 10 endmembers; flags and all count totals independently reconciled'}
(B/'核对记录.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));print(end.to_string(index=False))
