from pathlib import Path
import pandas as pd,numpy as np,importlib.util,collections,json,hashlib,zipfile,shutil
B=Path(__file__).resolve().parent;D=B.parent;A=D/'分子转化分析'
for sub in ['逐样本分子转化次数','逐样本转化峰对','核对记录']:(B/sub).mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('matching',D/'Meta-Metabolome_Ecology-master/run_molecular_transformations.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
read=lambda p:pd.read_csv(p,float_precision='round_trip')
allold=read(A/'全部样本_分子转化次数.csv');oldsummary=read(A/'样本汇总.csv');db=read(A/'方法来源/Transformation_Database_07-2020.csv');trans=list(zip(db.Name,db.Mass))
allold['H_C']=allold.H/allold.C.replace(0,np.nan)
mask=(allold.N>0)&(allold.C>0)&(allold.H_C<1.5)
excluded=allold[~mask].copy();excluded['reason']=np.select([excluded.N<=0,excluded.C<=0,excluded.H_C>=1.5],['N_not_positive','C_not_positive','HC_not_below_1.5'],default='invalid_HC');excluded.to_csv(B/'新增条件排除记录.csv',index=False,encoding='utf-8-sig')
filtered=allold[mask].copy();results=[];summ=[];verification=[]
for f in sorted((A/'逐样本转化峰对').glob('*.csv')):
 sid=f.name[:3];s=oldsummary[oldsummary.sample_id==sid].iloc[0];nodes=filtered[filtered.sample_id==sid].sort_values(['mz','source_row']).copy();allowed=set(nodes.source_row)
 edges=read(f);edges=edges[edges.source_row_x.isin(allowed)&edges.source_row_y.isin(allowed)].copy()
 # Run original mass matcher anew on the screened set; compare every pair to the induced network.
 masses=nodes.mz.to_numpy(dtype=float);fresh=m.match_all_masses(masses,trans);rows=nodes.source_row.to_numpy()
 expected={(int(rows[x]),int(rows[y])):trans[t][0] for (x,y),t in fresh}
 actual={(int(r.source_row_x),int(r.source_row_y)):r.transformation for r in edges.itertuples()}
 assert len(actual)==len(edges) and actual==expected,(sid,'fresh matcher disagrees')
 counts=collections.Counter();types=collections.defaultdict(set)
 for r in edges.itertuples():
  for rowid in [r.source_row_x,r.source_row_y]:counts[rowid]+=1;types[rowid].add(r.transformation)
 oldcount=nodes.transformation_count.copy();nodes['previous_full_network_count']=oldcount
 nodes['transformation_count']=nodes.source_row.map(lambda r:counts[r]).astype(int);nodes['transformation_type_count']=nodes.source_row.map(lambda r:len(types[r])).astype(int)
 nodes['RI_le1']=(nodes.transformation_count<=1).astype(int);nodes['RI_eq0']=(nodes.transformation_count==0).astype(int)
 assert nodes.transformation_count.sum()==2*len(edges)
 assert (nodes.transformation_count<=nodes.previous_full_network_count).all()
 nodes.to_csv(B/'逐样本分子转化次数'/f.name,index=False,encoding='utf-8-sig');edges.to_csv(B/'逐样本转化峰对'/f.name,index=False,encoding='utf-8-sig');results.append(nodes)
 n=len(nodes);nri=int(nodes.RI_le1.sum());n0=int(nodes.RI_eq0.sum())
 summ.append([sid,s.endmember,s['sample'],int(s.eligible_peaks),n,int(s.eligible_peaks)-n,len(edges),nri,n0,nri-n0,100*nri/n if n else None,100*n0/n if n else None])
 verification.append([sid,n,len(fresh),'PASS']);print(sid,s.endmember,'retained',n,'pairs',len(edges),'RI<=1',nri,'RI=0',n0,flush=True)
df=pd.concat(results,ignore_index=True);ri=df[df.RI_le1==1].copy();strict=df[df.RI_eq0==1].copy()
sample=pd.DataFrame(summ,columns=['sample_id','endmember','sample','previous_eligible_peaks','eligible_peaks','excluded_by_new_conditions','matched_pairs','RI_le1_peaks','RI_eq0_peaks','count_eq1','RI_le1_percent','RI_eq0_percent'])
end=sample.groupby('endmember',sort=False).agg(samples=('sample_id','nunique'),eligible_peaks=('eligible_peaks','sum'),matched_pairs=('matched_pairs','sum'),RI_le1_peaks=('RI_le1_peaks','sum'),RI_eq0_peaks=('RI_eq0_peaks','sum')).reset_index();end['RI_le1_percent']=end.RI_le1_peaks/end.eligible_peaks.replace(0,np.nan)*100;end['RI_eq0_percent']=end.RI_eq0_peaks/end.eligible_peaks.replace(0,np.nan)*100
sf=df.groupby(['endmember','sample_id','formula']).agg(peak_observations=('source_row','size'),min_degree=('transformation_count','min'),max_degree=('transformation_count','max')).reset_index()
for flag,threshold in [('le1',1),('eq0',0)]:sf['sample_any_RI_'+flag]=(sf.min_degree<=threshold).astype(int);sf['sample_all_RI_'+flag]=(sf.max_degree<=threshold).astype(int)
formula=sf.groupby(['endmember','formula']).agg(samples_detected=('sample_id','nunique'),peak_observations=('peak_observations','sum'),samples_any_RI_le1=('sample_any_RI_le1','sum'),samples_all_RI_le1=('sample_all_RI_le1','sum'),samples_any_RI_eq0=('sample_any_RI_eq0','sum'),samples_all_RI_eq0=('sample_all_RI_eq0','sum')).reset_index()
formula['always_RI_le1']=(formula.samples_all_RI_le1==formula.samples_detected).astype(int);formula['always_RI_eq0']=(formula.samples_all_RI_eq0==formula.samples_detected).astype(int)
for name,t in [('全部筛后分子_RI标记',df),('RI分子_转化次数小于等于1',ri),('严格RI分子_转化次数等于0',strict),('60样本汇总',sample),('10端元汇总',end),('各端元分子式RI检出汇总',formula)]:t.to_csv(B/(name+'.csv'),index=False,encoding='utf-8-sig')
pd.DataFrame(verification,columns=['sample_id','screened_peaks','fresh_matched_pairs','fresh_vs_induced_network']).to_csv(B/'核对记录/逐样本从头匹配核对.csv',index=False,encoding='utf-8-sig')
with pd.ExcelWriter(B/'DON_N大于0_HC小于1.5_RI结果.xlsx',engine='openpyxl') as x:
 end.to_excel(x,sheet_name='10端元汇总',index=False);sample.to_excel(x,sheet_name='60样本汇总',index=False);formula.to_excel(x,sheet_name='分子式检出汇总',index=False)
 for group in end.endmember:
  part=ri[ri.endmember==group];part.to_excel(x,sheet_name=group,index=False);part.to_csv(B/(group+'_RI分子.csv'),index=False,encoding='utf-8-sig')
assert len(sample)==60 and len(end)==10
assert len(df)==len(filtered) and len(df)+len(excluded)==len(allold)
assert (df.N>0).all() and (df.H_C<1.5).all() and (df.C>0).all()
assert df.transformation_count.sum()==2*sample.matched_pairs.sum()
assert sample.RI_le1_peaks.sum()==len(ri) and sample.RI_eq0_peaks.sum()==len(strict)
r={'samples':len(sample),'endmembers':len(end),'previous_peak_observations':len(allold),'screened_peak_observations':len(df),'newly_excluded_peak_observations':len(excluded),'matched_pairs':int(sample.matched_pairs.sum()),'RI_le1_peak_observations':len(ri),'RI_eq0_peak_observations':len(strict),'RI_le1_unique_formulas':ri.formula.nunique(),'RI_eq0_unique_formulas':strict.formula.nunique(),'empty_samples':sample.loc[sample.eligible_peaks==0,['sample_id','endmember','sample']].to_dict('records'),'new_filters':['N>0','C>0 (H/C defined)','H/C<1.5 strictly'],'network_scope':'screen molecules first, rebuild each sample network, then RI threshold; never pool samples','checks':'all 60 screened networks independently rematched using original matcher; pairs and transformation assignments exactly agree; degree sums and summary counts pass'}
(B/'核对记录/结果核对.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False,indent=2),flush=True)
